# 2 · Situs web (Vercel) — 13 file

Salin ke repo dengan nama dan folder persis seperti judul tiap bagian.

Cara membuat tiap file di GitHub: **Add file → Create new file**, ketik nama file lengkap dengan folder (garis miring membuat folder otomatis), tempel isinya, lalu **Commit changes**. Kalau tampilan di HP menyulitkan, aktifkan *Desktop site* di browser.

### `apps/web/package.json`

````json
{
  "name": "web",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^15.5.0",
    "qrcode": "^1.5.4",
    "react": "^19.1.0",
    "react-dom": "^19.1.0"
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "@types/qrcode": "^1.5.5",
    "@types/react": "^19.1.0",
    "@types/react-dom": "^19.1.0",
    "typescript": "^5.6.0"
  }
}
````

### `apps/web/tsconfig.json`

````json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }]
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
````

### `apps/web/lib/config.ts`

````ts
// Semua nama tampilan dan alamat dikumpulkan di sini supaya mudah diganti saat rebrand.
export const APP_NAME = "Main Bareng"; // placeholder sampai replica-brand
export const RELAY_URL = (process.env.NEXT_PUBLIC_RELAY_URL ?? "").replace(/\/+$/, "");
````

### `apps/web/lib/link.ts`

````ts
// Klien relay untuk browser: dipakai halaman layar dan halaman controller.
// Mengurus: sambung, hello, ping/pong, sambung ulang dengan backoff, dan pemeriksaan
// bahwa sesinya masih ada. Tidak bergantung pada React.

export type Role = "screen" | "controller";
export type Device = { id: number; role: Role; nickname: string };
export type LinkStatus = "connecting" | "open" | "reconnecting" | "closed";
export type CloseReason =
  | "not_found"
  | "not_allowed"
  | "full"
  | "expired"
  | "replaced"
  | "bad_hello"
  | "stopped";

export type Welcome = { deviceId: number; deviceToken?: string; code: string; devices: Device[] };

export type LinkOptions = {
  relayUrl: string; // contoh: https://game-relay.akun-anda.workers.dev
  code: string;
  role: Role;
  token?: string; // layar: host_token. controller: device_token bila sambung ulang.
  nickname?: string;
  onStatus?: (status: LinkStatus, reason?: CloseReason) => void;
  onWelcome?: (w: Welcome) => void;
  onJoined?: (d: Device) => void;
  onLeft?: (id: number) => void;
  onMessage?: (from: number, data: unknown) => void;
  onError?: (code: string) => void;
  // Hanya untuk pengujian:
  WebSocketImpl?: typeof WebSocket;
  fetchImpl?: typeof fetch;
  backoffBaseMs?: number;
  pingMs?: number;
};

const TERMINAL: Record<number, CloseReason> = {
  4000: "replaced",
  4003: "not_allowed",
  4009: "full",
  4010: "expired",
  4011: "bad_hello",
};

export function wsUrlFor(relayUrl: string, code: string): string {
  const u = new URL(relayUrl);
  u.protocol = u.protocol === "http:" ? "ws:" : "wss:";
  u.pathname = `/v1/ws/${code}`;
  u.search = "";
  return u.toString();
}

export class LinkClient {
  opts: LinkOptions;
  status: LinkStatus = "connecting";
  deviceId: number | null = null;
  devices = new Map<number, Device>();

  private ws: WebSocket | null = null;
  private stopped = true;
  private everOpened = false;
  private attempts = 0;
  private retryTimer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private probeTimer: ReturnType<typeof setTimeout> | null = null;
  private lastPong = 0;
  private connecting = false;

  constructor(opts: LinkOptions) {
    this.opts = opts;
  }

  start(): void {
    this.stopped = false;
    this.attempts = 0;
    if (typeof document !== "undefined") document.addEventListener("visibilitychange", this.onVisible);
    void this.connect();
  }

  stop(): void {
    this.stopped = true;
    this.clearTimers();
    if (typeof document !== "undefined") document.removeEventListener("visibilitychange", this.onVisible);
    const ws = this.ws;
    this.ws = null;
    try {
      ws?.close(1000, "bye");
    } catch {}
    this.setStatus("closed", "stopped");
  }

  // Mengembalikan false bila belum tersambung (pesan tidak terkirim).
  send(to: number | "all", data: unknown): boolean {
    const ws = this.ws;
    if (!ws || ws.readyState !== 1 || this.deviceId === null) return false;
    ws.send(JSON.stringify({ t: "msg", to, data }));
    return true;
  }

  // ---------------------------------------------------------- internal

  private setStatus(s: LinkStatus, reason?: CloseReason): void {
    this.status = s;
    this.opts.onStatus?.(s, reason);
  }

  private clearTimers(): void {
    if (this.retryTimer) clearTimeout(this.retryTimer);
    if (this.probeTimer) clearTimeout(this.probeTimer);
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.retryTimer = this.probeTimer = null;
    this.pingTimer = null;
  }

  private terminate(reason: CloseReason): void {
    this.stopped = true;
    this.clearTimers();
    if (typeof document !== "undefined") document.removeEventListener("visibilitychange", this.onVisible);
    const ws = this.ws;
    this.ws = null;
    try {
      ws?.close(1000, "bye");
    } catch {}
    this.setStatus("closed", reason);
  }

  private async checkExists(): Promise<boolean | undefined> {
    try {
      const f = this.opts.fetchImpl ?? fetch;
      const r = await f(`${this.opts.relayUrl}/v1/sessions/${this.opts.code}`);
      if (!r.ok) return undefined; // batas laju atau gangguan: coba lagi nanti
      const j = (await r.json()) as { exists?: boolean };
      return j.exists === true;
    } catch {
      return undefined; // tidak ada jaringan: coba lagi nanti
    }
  }

  private async connect(): Promise<void> {
    if (this.stopped || this.connecting || this.ws) return;
    this.connecting = true;
    let exists: boolean | undefined;
    try {
      this.setStatus(this.everOpened ? "reconnecting" : "connecting");
      exists = await this.checkExists();
    } finally {
      this.connecting = false;
    }
    if (this.stopped || this.ws) return;
    if (exists === false) return this.terminate("not_found");
    if (exists === undefined) return this.scheduleRetry();

    const WS = this.opts.WebSocketImpl ?? WebSocket;
    const ws = new WS(wsUrlFor(this.opts.relayUrl, this.opts.code));
    this.ws = ws;
    ws.onopen = () => {
      if (this.ws !== ws) return;
      ws.send(
        JSON.stringify({
          t: "hello",
          v: 1,
          role: this.opts.role,
          token: this.opts.token,
          nickname: this.opts.nickname,
        }),
      );
    };
    ws.onmessage = (e: MessageEvent) => {
      if (this.ws === ws) this.onRaw(e.data);
    };
    ws.onclose = (e: CloseEvent) => this.drop(ws, e.code);
    ws.onerror = () => {}; // onclose menyusul dan ditangani di sana
  }

  private onRaw(data: unknown): void {
    if (data === "pong") {
      this.lastPong = Date.now();
      return;
    }
    if (typeof data !== "string") return;
    let m: any;
    try {
      m = JSON.parse(data);
    } catch {
      return;
    }
    switch (m.t) {
      case "welcome": {
        this.deviceId = m.device_id;
        if (typeof m.device_token === "string") this.opts.token = m.device_token;
        this.devices = new Map((m.devices as Device[]).map((d) => [d.id, d]));
        this.attempts = 0;
        this.everOpened = true;
        this.startPing();
        this.setStatus("open");
        this.opts.onWelcome?.({
          deviceId: m.device_id,
          deviceToken: m.device_token,
          code: m.code,
          devices: Array.from(this.devices.values()),
        });
        break;
      }
      case "joined":
        this.devices.set(m.device.id, m.device);
        this.opts.onJoined?.(m.device);
        break;
      case "left":
        this.devices.delete(m.device_id);
        this.opts.onLeft?.(m.device_id);
        break;
      case "msg":
        this.opts.onMessage?.(m.from, m.data);
        break;
      case "error":
        this.opts.onError?.(m.code);
        break;
    }
  }

  // Koneksi ini berakhir (ditutup atau terdeteksi mati). Terminal atau coba lagi.
  private drop(ws: WebSocket, code: number): void {
    if (this.ws !== ws) return; // koneksi lama yang sudah digantikan
    this.ws = null;
    this.deviceId = null;
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.pingTimer = null;
    try {
      ws.close();
    } catch {}
    if (this.stopped) return;
    const terminal = TERMINAL[code];
    if (terminal) return this.terminate(terminal);
    this.scheduleRetry();
  }

  private scheduleRetry(): void {
    if (this.stopped) return;
    this.setStatus("reconnecting");
    const base = this.opts.backoffBaseMs ?? 500;
    const delay = Math.min(5000, base * 2 ** this.attempts) * (0.5 + Math.random() / 2);
    this.attempts += 1;
    this.retryTimer = setTimeout(() => void this.connect(), delay);
  }

  private startPing(): void {
    if (this.pingTimer) clearInterval(this.pingTimer);
    const every = this.opts.pingMs ?? 20_000;
    this.lastPong = Date.now();
    this.pingTimer = setInterval(() => {
      const ws = this.ws;
      if (!ws || ws.readyState !== 1) return;
      if (Date.now() - this.lastPong > every * 2 + Math.min(5000, every)) return this.drop(ws, 1006); // tidak ada jawaban: anggap mati
      ws.send("ping");
    }, every);
  }

  // Saat tab kembali terlihat (misalnya HP dibuka dari kunci layar), pastikan koneksi masih hidup.
  private onVisible = (): void => {
    if (this.stopped || document.visibilityState !== "visible") return;
    const ws = this.ws;
    if (ws && ws.readyState === 1) {
      const sentAt = Date.now();
      ws.send("ping");
      if (this.probeTimer) clearTimeout(this.probeTimer);
      this.probeTimer = setTimeout(() => {
        if (this.ws === ws && this.lastPong < sentAt) this.drop(ws, 1006);
      }, 3000);
    } else if (!ws) {
      if (this.retryTimer) clearTimeout(this.retryTimer);
      this.attempts = 0;
      void this.connect();
    }
  };
}
````

### `apps/web/components/PlayerBadge.tsx`

````tsx
// Penanda pemain: warna + nomor + bentuk, jadi tetap terbedakan untuk pemain buta warna.
import type { ReactNode } from "react";

function starPoints(): string {
  const pts: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = ((-90 + i * 36) * Math.PI) / 180;
    const r = i % 2 === 0 ? 19 : 8.5;
    pts.push(`${(20 + r * Math.cos(a)).toFixed(1)},${(20 + r * Math.sin(a)).toFixed(1)}`);
  }
  return pts.join(" ");
}

// Urutan bentuk mengikuti nomor pemain 1..8.
const SHAPES: ReactNode[] = [
  <circle key="1" cx="20" cy="20" r="18" />,
  <rect key="2" x="3" y="3" width="34" height="34" rx="6" />,
  <polygon key="3" points="20,3 38,36 2,36" />,
  <polygon key="4" points="20,1 39,20 20,39 1,20" />,
  <polygon key="5" points={starPoints()} />,
  <polygon key="6" points="14,2 26,2 26,14 38,14 38,26 26,26 26,38 14,38 14,26 2,26 2,14 14,14" />,
  <path key="7" d="M20 36 C4 24 2 14 8 8 C13 3 19 6 20 10 C21 6 27 3 32 8 C38 14 36 24 20 36 Z" />,
  <polygon key="8" points="20,2 36,11 36,29 20,38 4,29 4,11" />,
];

export function playerNumber(deviceId: number): number {
  return ((Math.max(1, deviceId) - 1) % 8) + 1;
}

export default function PlayerBadge({ id, size = 40 }: { id: number; size?: number }) {
  const n = playerNumber(id);
  return (
    <svg role="img" aria-label={`Pemain ${n}`} width={size} height={size} viewBox="0 0 40 40">
      <g style={{ fill: `var(--color-player-${n})` }}>{SHAPES[n - 1]}</g>
      <text
        x="20"
        y="26"
        textAnchor="middle"
        fontSize="18"
        fontWeight="700"
        style={{ fill: "var(--color-on-player)" }}
      >
        {n}
      </text>
    </svg>
  );
}
````

### `apps/web/components/StatusBanner.tsx`

````tsx
import type { CloseReason, LinkStatus } from "../lib/link";

const CLOSED_TEXT: Record<CloseReason, string | null> = {
  not_found: "Kode tidak ditemukan atau sesi sudah berakhir.",
  expired: "Sesi sudah berakhir.",
  full: "Sesi sudah penuh.",
  replaced: "Dibuka di tab atau perangkat lain.",
  not_allowed: "Tidak diizinkan masuk ke sesi ini.",
  bad_hello: "Sambungan gagal. Coba lagi.",
  stopped: null,
};

export default function StatusBanner({ status, reason }: { status: LinkStatus; reason?: CloseReason }) {
  if (status === "open") return null;
  let kind: "warn" | "bad" = "warn";
  let text: string | null = "Menyambung…";
  if (status === "reconnecting") text = "Koneksi terputus. Mencoba tersambung lagi…";
  if (status === "closed") {
    kind = "bad";
    text = reason ? CLOSED_TEXT[reason] : null;
  }
  if (!text) return null;
  return (
    <div className={`banner banner-${kind}`} role={kind === "bad" ? "alert" : "status"}>
      {text}
    </div>
  );
}
````

### `apps/web/app/layout.tsx`

````tsx
import type { Metadata, Viewport } from "next";
import { APP_NAME } from "../lib/config";
import "./tokens.css";
import "./globals.css";

export const metadata: Metadata = {
  title: APP_NAME,
  description: "Layar besar jadi konsol, HP jadi controller. Tanpa instal.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0d1017",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
````

### `apps/web/app/page.tsx`

````tsx
import Link from "next/link";
import { APP_NAME } from "../lib/config";

export default function Home() {
  return (
    <main className="page center stack">
      <h1 className="display">{APP_NAME}</h1>
      <p className="muted">Layar besar jadi konsol, HP jadi controller. Tanpa instal.</p>
      <div className="stack-row">
        <Link className="btn btn-primary btn-lg" href="/screen">
          Jadikan layar ini konsol
        </Link>
        <Link className="btn btn-secondary btn-lg" href="/join">
          Gabung dengan kode
        </Link>
      </div>
    </main>
  );
}
````

### `apps/web/app/tokens.css`

````css
/* Dihasilkan dari tokens.json oleh build-tokens.py. Jangan diedit tangan. */
:root {
  --color-bg: #0d1017;
  --color-surface: #161a24;
  --color-surface-raised: #1f2431;
  --color-border: #2c3343;
  --color-border-input: #7d8798;
  --color-text: #f2f4f8;
  --color-text-muted: #a9b2c1;
  --color-accent: #9b8cff;
  --color-on-accent: #0b0e17;
  --color-danger: #ff7b7b;
  --color-on-danger: #1a0707;
  --color-success: #4cd694;
  --color-on-success: #04170d;
  --color-warning: #f5c451;
  --color-on-warning: #1c1400;
  --color-player-1: #f5a524;
  --color-player-2: #56b4e9;
  --color-player-3: #2fcb9a;
  --color-player-4: #f0e442;
  --color-player-5: #4c8dff;
  --color-player-6: #ff6b5e;
  --color-player-7: #e58ad0;
  --color-player-8: #c9d1de;
  --color-on-player: #0b0e17;
  --color-qr-bg: #ffffff;
  --font-sans: Inter, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
  --font-display: Fredoka, Inter, system-ui, sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
  --text-xs: 0.75rem;
  --text-xs-line: 1rem;
  --text-xs-weight: 500;
  --text-sm: 0.875rem;
  --text-sm-line: 1.25rem;
  --text-sm-weight: 400;
  --text-base: 1rem;
  --text-base-line: 1.5rem;
  --text-base-weight: 400;
  --text-lg: 1.25rem;
  --text-lg-line: 1.75rem;
  --text-lg-weight: 600;
  --text-xl: 1.75rem;
  --text-xl-line: 2.125rem;
  --text-xl-weight: 700;
  --text-display: 2.5rem;
  --text-display-line: 2.75rem;
  --text-display-weight: 700;
  --text-huge: 6rem;
  --text-huge-line: 6.25rem;
  --text-huge-weight: 700;
  --text-huge-tracking: 0.12em;
  --space-0: 0;
  --space-1: 0.25rem;
  --space-2: 0.5rem;
  --space-3: 0.75rem;
  --space-4: 1rem;
  --space-5: 1.5rem;
  --space-6: 2rem;
  --space-7: 3rem;
  --space-8: 4rem;
  --space-9: 6rem;
  --radius-sm: 0.5rem;
  --radius-md: 0.875rem;
  --radius-lg: 1.5rem;
  --radius-pill: 999px;
  --shadow-card: 0 1px 2px rgba(0,0,0,.40), 0 2px 8px rgba(0,0,0,.30);
  --shadow-pop: 0 16px 40px rgba(0,0,0,.55);
  --shadow-focus: 0 0 0 0.1875rem var(--color-bg), 0 0 0 0.375rem var(--color-accent);
  --dur-fast: 120ms;
  --dur-base: 200ms;
  --ease: cubic-bezier(.2,.8,.2,1);
  --safe-x: 5vw;
  --safe-y: 5vh;
  --touch-min: 3rem;
  --touch-pad: 4rem;
  color-scheme: dark;
}

html { font-size: 16px; }
/* Skala tv: semua ukuran memakai rem, jadi satu baris ini membesarkan seluruh UI layar utama. */
html[data-surface="tv"] { font-size: 24px; }

body { background: var(--color-bg); color: var(--color-text); font-family: var(--font-sans);
       font-size: var(--text-base); line-height: var(--text-base-line); }

:focus-visible { outline: none; box-shadow: var(--shadow-focus); }

@media (prefers-reduced-motion: reduce) {
  :root { --dur-fast: 0ms; --dur-base: 0ms; }
  * { animation-duration: 0ms !important; transition-duration: 0ms !important; }
  [data-focus-scale] { transform: none !important; }
}
````

### `apps/web/app/globals.css`

````css
/* Gaya dasar vertical slice. Semua nilai berasal dari token (tokens.css). Komponen yang lebih
   lengkap menyusul di langkah build berikutnya (halaman /design). */

*,
*::before,
*::after {
  box-sizing: border-box;
}
html,
body {
  margin: 0;
  min-height: 100%;
}
body {
  min-height: 100dvh;
  -webkit-tap-highlight-color: transparent;
}

h1,
h2,
p,
ol,
ul {
  margin: 0;
}
ul,
ol {
  padding: 0;
  list-style: none;
}

/* ------------------------------------------------------------ tata letak */

.page {
  min-height: 100dvh;
  padding: max(var(--space-5), env(safe-area-inset-top)) var(--space-5) max(var(--space-5), env(safe-area-inset-bottom));
  max-width: 30rem;
  margin: 0 auto;
}
.center {
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  align-items: stretch;
}
.stack {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}
.stack-row {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
  justify-content: center;
}
.grow {
  flex: 1;
  min-width: 0;
}

/* Layar utama (tv): dua kolom di dalam zona aman 5 persen. */
html[data-surface="tv"] body {
  padding: var(--safe-y) var(--safe-x);
}
.tv {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--space-7);
  align-items: start;
}
@media (max-width: 50rem) {
  .tv {
    grid-template-columns: 1fr;
  }
}

/* ------------------------------------------------------------- tipografi */

.display {
  font-family: var(--font-display);
  font-size: var(--text-display);
  line-height: var(--text-display-line);
  font-weight: var(--text-display-weight);
}
.title {
  font-family: var(--font-display);
  font-size: var(--text-xl);
  line-height: var(--text-xl-line);
  font-weight: var(--text-xl-weight);
}
.muted {
  color: var(--color-text-muted);
}
.small {
  font-size: var(--text-sm);
  line-height: var(--text-sm-line);
}
.steps {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  font-size: var(--text-lg);
  line-height: var(--text-lg-line);
  font-weight: 400;
}

/* ----------------------------------------------------------------- tombol */

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: var(--touch-min);
  padding: var(--space-2) var(--space-5);
  border: 1px solid transparent;
  border-radius: var(--radius-md);
  font: inherit;
  font-weight: 600;
  text-decoration: none;
  cursor: pointer;
  transition: transform var(--dur-fast) var(--ease);
}
.btn:active {
  transform: scale(0.98);
}
.btn:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
.btn-lg {
  min-height: var(--touch-pad);
  font-size: var(--text-lg);
}
.btn-primary {
  background: var(--color-accent);
  color: var(--color-on-accent);
}
.btn-secondary {
  background: var(--color-surface-raised);
  color: var(--color-text);
  border-color: var(--color-border);
}
.btn-ghost {
  background: transparent;
  color: var(--color-text);
}

/* --------------------------------------------------------------- formulir */

.field-group {
  text-align: left;
}
.field {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}
.label {
  font-size: var(--text-sm);
  line-height: var(--text-sm-line);
  font-weight: 600;
}
.input {
  min-height: var(--touch-pad);
  padding: var(--space-2) var(--space-4);
  border: 1px solid var(--color-border-input);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: max(1rem, var(--text-base)); /* minimal 16px agar iOS tidak memperbesar halaman */
}
.input-code {
  font-family: var(--font-mono);
  font-size: var(--text-xl);
  letter-spacing: 0.3em;
  text-align: center;
  text-transform: uppercase;
}

/* ------------------------------------------------------------ status/banner */

.banner {
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-md);
  background: var(--color-surface-raised);
  border-left: var(--space-1) solid var(--color-warning);
  text-align: left;
}
.banner-bad {
  border-left-color: var(--color-danger);
}

/* -------------------------------------------------------- layar: kode & QR */

.code {
  font-family: var(--font-display);
  font-size: var(--text-huge);
  line-height: var(--text-huge-line);
  font-weight: var(--text-huge-weight);
  letter-spacing: var(--text-huge-tracking);
  text-align: center;
  padding: var(--space-5) var(--space-4);
  background: var(--color-surface);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-card);
}
.qr {
  width: 14rem;
  padding: var(--space-3);
  background: var(--color-qr-bg); /* QR harus gelap di atas terang agar terbaca kamera, apa pun temanya */
  border-radius: var(--radius-md);
}
.qr svg {
  display: block;
  width: 100%;
  height: auto;
}

/* ----------------------------------------------------------------- pemain */

.players {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}
.player {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-card);
}
.player-name {
  flex: 1;
  min-width: 0;
  font-size: var(--text-lg);
  line-height: var(--text-lg-line);
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.count {
  font-family: var(--font-display);
  font-size: var(--text-xl);
  font-weight: 700;
}

/* ------------------------------------------------------------- controller */

.controller {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  min-height: 100dvh;
  max-width: 30rem;
  margin: 0 auto;
  padding: max(var(--space-4), env(safe-area-inset-top)) var(--space-4) max(var(--space-4), env(safe-area-inset-bottom));
}
.controller-head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}
.badge-empty {
  width: 2.5rem;
  height: 2.5rem;
}
.pad {
  flex: 1;
  min-height: 16rem;
  border: 2px solid var(--color-border);
  border-radius: var(--radius-lg);
  background: var(--color-surface-raised);
  color: var(--color-text);
  font-family: var(--font-display);
  font-size: var(--text-display);
  font-weight: 700;
  touch-action: none; /* tidak menggulir atau memperbesar saat ditekan */
  user-select: none;
  -webkit-user-select: none;
  -webkit-touch-callout: none;
  cursor: pointer;
}
.pad:active:not(:disabled) {
  background: var(--color-accent);
  color: var(--color-on-accent);
  border-color: var(--color-accent);
}
.pad:disabled {
  opacity: 0.45;
  font-size: var(--text-lg);
  cursor: not-allowed;
}
.stats {
  display: flex;
  justify-content: space-between;
  color: var(--color-text-muted);
  font-size: var(--text-sm);
  line-height: var(--text-sm-line);
}
````

### `apps/web/app/screen/page.tsx`

````tsx
"use client";

// Layar utama (TV atau laptop): membuat sesi, menampilkan kode dan QR, menunjukkan pemain.
// Vertical slice: setiap ketukan dari HP menaikkan penghitung, dan layar membalas "ack"
// supaya HP bisa mengukur waktu bolak-balik (ping).

import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import { LinkClient } from "../../lib/link";
import type { CloseReason, Device, LinkStatus } from "../../lib/link";
import { APP_NAME, RELAY_URL } from "../../lib/config";
import PlayerBadge from "../../components/PlayerBadge";
import StatusBanner from "../../components/StatusBanner";

type Saved = { code: string; hostToken: string };
const KEY = "link:screen";

function readSaved(): Saved | null {
  try {
    const v = sessionStorage.getItem(KEY);
    return v ? (JSON.parse(v) as Saved) : null;
  } catch {
    return null;
  }
}
function writeSaved(s: Saved | null): void {
  try {
    if (s) sessionStorage.setItem(KEY, JSON.stringify(s));
    else sessionStorage.removeItem(KEY);
  } catch {}
}

async function stillExists(code: string): Promise<boolean> {
  try {
    const r = await fetch(`${RELAY_URL}/v1/sessions/${code}`);
    if (!r.ok) return true; // tidak yakin: biarkan LinkClient yang memutuskan
    return ((await r.json()) as { exists?: boolean }).exists === true;
  } catch {
    return true;
  }
}

async function createSession(): Promise<Saved> {
  const r = await fetch(`${RELAY_URL}/v1/sessions`, { method: "POST" });
  if (!r.ok) throw new Error(r.status === 429 ? "Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi." : "Relay tidak bisa dihubungi.");
  const j = (await r.json()) as { code: string; host_token: string };
  return { code: j.code, hostToken: j.host_token };
}

export default function ScreenPage() {
  const [epoch, setEpoch] = useState(0);
  const [code, setCode] = useState<string | null>(null);
  const [status, setStatus] = useState<LinkStatus>("connecting");
  const [reason, setReason] = useState<CloseReason | undefined>();
  const [players, setPlayers] = useState<Device[]>([]);
  const [taps, setTaps] = useState<Record<number, number>>({});
  const [qr, setQr] = useState("");
  const [origin, setOrigin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const linkRef = useRef<LinkClient | null>(null);

  useEffect(() => {
    document.documentElement.dataset.surface = "tv";
    setOrigin(window.location.origin);
    return () => {
      delete document.documentElement.dataset.surface;
    };
  }, []);

  useEffect(() => {
    if (!RELAY_URL) {
      setError("Alamat relay belum diatur (NEXT_PUBLIC_RELAY_URL).");
      return;
    }
    let cancelled = false;
    let link: LinkClient | null = null;
    setError(null);
    setStatus("connecting");
    setReason(undefined);
    setPlayers([]);
    setTaps({});

    (async () => {
      try {
        let s = readSaved();
        if (s && !(await stillExists(s.code))) s = null; // sesi lama sudah hilang
        if (!s) {
          s = await createSession();
          writeSaved(s);
        }
        if (cancelled) return;
        setCode(s.code);
        link = new LinkClient({
          relayUrl: RELAY_URL,
          code: s.code,
          role: "screen",
          token: s.hostToken,
          onStatus: (st, r) => {
            setStatus(st);
            setReason(r);
          },
          onWelcome: (w) => setPlayers(w.devices.filter((d) => d.role === "controller")),
          onJoined: (d) => {
            if (d.role !== "controller") return;
            setPlayers((p) => [...p.filter((x) => x.id !== d.id), d].sort((a, b) => a.id - b.id));
          },
          onLeft: (id) => setPlayers((p) => p.filter((x) => x.id !== id)),
          onMessage: (from, data) => {
            const m = data as { k?: string; ts?: number } | null;
            if (m && m.k === "tap") {
              setTaps((t) => ({ ...t, [from]: (t[from] ?? 0) + 1 }));
              link?.send(from, { k: "ack", ts: m.ts });
            }
          },
        });
        linkRef.current = link;
        link.start();
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "Terjadi kesalahan.");
      }
    })();

    return () => {
      cancelled = true;
      link?.stop();
      linkRef.current = null;
    };
  }, [epoch]);

  // QR berisi alamat gabung langsung dengan kode, supaya HP tidak perlu mengetik.
  useEffect(() => {
    if (!code || !origin) return;
    let cancelled = false;
    QRCode.toString(`${origin}/join?c=${code}`, { type: "svg", margin: 1 })
      .then((svg) => {
        if (!cancelled) setQr(svg);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [code, origin]);

  const newSession = () => {
    writeSaved(null);
    setCode(null);
    setQr("");
    setEpoch((e) => e + 1);
  };

  const total = Object.values(taps).reduce((a, b) => a + b, 0);
  const ended = status === "closed" && reason !== "stopped";

  if (error) {
    return (
      <main className="page center stack">
        <div className="banner banner-bad" role="alert">
          {error}
        </div>
        <button className="btn btn-primary btn-lg" onClick={newSession}>
          Coba lagi
        </button>
      </main>
    );
  }

  return (
    <main className="tv">
      <section className="stack" aria-label="Cara bergabung">
        <h1 className="title">Gabung dari HP</h1>
        <ol className="steps">
          <li>
            Buka <strong>{origin ? origin.replace(/^https?:\/\//, "") : "…"}/join</strong> di HP
          </li>
          <li>Masukkan kode ini, atau pindai QR</li>
        </ol>
        <div className="code" role="img" aria-label={code ? `Kode sesi: ${code.split("").join(" ")}` : "Kode sesi sedang dibuat"}>
          {code ?? "·····"}
        </div>
        {qr && (
          <div className="qr" role="img" aria-label="QR untuk bergabung" dangerouslySetInnerHTML={{ __html: qr }} />
        )}
      </section>

      <section className="stack" aria-label="Pemain">
        <StatusBanner status={status} reason={reason} />
        {ended && (
          <button className="btn btn-primary btn-lg" onClick={newSession}>
            Buat sesi baru
          </button>
        )}
        <h2 className="title">Pemain ({players.length})</h2>
        {players.length === 0 ? (
          <p className="muted">Belum ada yang bergabung. Buka {APP_NAME} di HP lalu masukkan kodenya.</p>
        ) : (
          <ul className="players" aria-live="polite">
            {players.map((p) => (
              <li key={p.id} className="player">
                <PlayerBadge id={p.id} size={48} />
                <span className="player-name">{p.nickname}</span>
                <span className="count" aria-label={`${taps[p.id] ?? 0} ketukan`}>
                  {taps[p.id] ?? 0}
                </span>
              </li>
            ))}
          </ul>
        )}
        <p className="muted">Total ketukan: {total}</p>
      </section>
    </main>
  );
}
````

### `apps/web/app/join/page.tsx`

````tsx
"use client";

// HP sebagai controller. Dua cara masuk:
//  - dari QR di layar: /join?c=KODE, langsung tersambung (1 aksi: pindai)
//  - mengetik kode di formulir (2 aksi: buka situs, ketik kode)
// Vertical slice: satu tombol besar. Setiap ketukan dikirim ke layar, layar membalas "ack",
// dan HP menampilkan waktu bolak-balik (ping).

import { Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { LinkClient } from "../../lib/link";
import type { CloseReason, LinkStatus } from "../../lib/link";
import { APP_NAME, RELAY_URL } from "../../lib/config";
import PlayerBadge from "../../components/PlayerBadge";
import StatusBanner from "../../components/StatusBanner";

const NICK_KEY = "link:nick";
const ACTIVE_KEY = "link:active";
const tokenKey = (code: string) => `link:dt:${code}`;

function cleanCode(v: string | null | undefined): string {
  return (v ?? "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 5);
}
function store(kind: "local" | "session") {
  try {
    return kind === "local" ? window.localStorage : window.sessionStorage;
  } catch {
    return null;
  }
}
function median(xs: number[]): number {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

function Controller() {
  const params = useSearchParams();
  const [code, setCode] = useState(cleanCode(params.get("c")));
  const [nick, setNick] = useState("");
  const [active, setActive] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [status, setStatus] = useState<LinkStatus>("connecting");
  const [reason, setReason] = useState<CloseReason | undefined>();
  const [myId, setMyId] = useState<number | null>(null);
  const [myTaps, setMyTaps] = useState(0);
  const [rtts, setRtts] = useState<number[]>([]);
  const linkRef = useRef<LinkClient | null>(null);

  // Saat dibuka: ambil nama tersimpan; masuk otomatis bila ada kode di URL atau sesi sebelumnya.
  useEffect(() => {
    setNick(store("local")?.getItem(NICK_KEY) ?? "");
    const fromUrl = cleanCode(params.get("c"));
    const fromTab = cleanCode(store("session")?.getItem(ACTIVE_KEY));
    const start = fromUrl.length === 5 ? fromUrl : fromTab.length === 5 ? fromTab : null;
    if (start) {
      setCode(start);
      setActive(start);
    }
  }, []);

  // Sambungan ke relay, selama ada kode aktif.
  useEffect(() => {
    if (!active) return;
    if (!RELAY_URL) {
      setNotice("Alamat relay belum diatur (NEXT_PUBLIC_RELAY_URL).");
      setActive(null);
      return;
    }
    store("session")?.setItem(ACTIVE_KEY, active);
    setNotice(null);
    setMyTaps(0);
    setRtts([]);
    setStatus("connecting");
    setReason(undefined);

    const nickname = store("local")?.getItem(NICK_KEY) ?? "";
    const link = new LinkClient({
      relayUrl: RELAY_URL,
      code: active,
      role: "controller",
      token: store("session")?.getItem(tokenKey(active)) ?? undefined,
      nickname,
      onStatus: (s, r) => {
        setStatus(s);
        setReason(r);
        if (s === "closed" && r && r !== "stopped") {
          // Sesi hilang atau ditolak: kembali ke formulir dengan penjelasan.
          store("session")?.removeItem(ACTIVE_KEY);
          if (r !== "replaced") store("session")?.removeItem(tokenKey(active));
          setActive(null);
          setMyId(null);
          setNotice(
            r === "not_found" || r === "expired"
              ? "Kode tidak ditemukan atau sesi sudah berakhir."
              : r === "full"
                ? "Sesi sudah penuh."
                : r === "replaced"
                  ? "Controller ini dibuka di tab atau perangkat lain."
                  : "Tidak bisa bergabung. Coba lagi.",
          );
        }
      },
      onWelcome: (w) => {
        setMyId(w.deviceId);
        if (w.deviceToken) store("session")?.setItem(tokenKey(active), w.deviceToken);
      },
      onMessage: (_from, data) => {
        const m = data as { k?: string; ts?: number } | null;
        if (m && m.k === "ack" && typeof m.ts === "number") {
          const rtt = performance.now() - m.ts;
          setRtts((r) => [...r.slice(-9), rtt]);
        }
      },
    });
    linkRef.current = link;
    link.start();
    return () => {
      link.stop();
      linkRef.current = null;
    };
  }, [active]);

  // Jaga layar HP tetap menyala selama bermain.
  useEffect(() => {
    if (status !== "open") return;
    let lock: WakeLockSentinel | null = null;
    const acquire = async () => {
      try {
        if ("wakeLock" in navigator && document.visibilityState === "visible") {
          lock = await navigator.wakeLock.request("screen");
        }
      } catch {}
    };
    void acquire();
    const onVis = () => {
      if (document.visibilityState === "visible") void acquire();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      lock?.release().catch(() => {});
    };
  }, [status]);

  const tap = () => {
    const ok = linkRef.current?.send(0, { k: "tap", ts: performance.now() });
    if (ok) {
      setMyTaps((n) => n + 1);
      navigator.vibrate?.(10);
    }
  };

  const join = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length !== 5) return;
    const name = nick.trim();
    if (name) store("local")?.setItem(NICK_KEY, name);
    else store("local")?.removeItem(NICK_KEY);
    setActive(code);
  };

  const leave = () => {
    if (active) store("session")?.removeItem(tokenKey(active));
    store("session")?.removeItem(ACTIVE_KEY);
    setActive(null);
    setMyId(null);
    setNotice(null);
  };

  // ------------------------------------------------------------- formulir
  if (!active) {
    return (
      <main className="page center stack">
        <h1 className="display">{APP_NAME}</h1>
        <p className="muted">Masukkan kode yang tampil di layar besar.</p>
        {notice && (
          <div className="banner banner-bad" role="alert">
            {notice}
          </div>
        )}
        <form className="stack field-group" onSubmit={join}>
          <label className="field">
            <span className="label">Kode</span>
            <input
              className="input input-code"
              value={code}
              onChange={(e) => setCode(cleanCode(e.target.value))}
              inputMode="text"
              autoCapitalize="characters"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              maxLength={5}
              placeholder="·····"
              aria-describedby={notice ? undefined : "kode-bantuan"}
            />
          </label>
          <label className="field">
            <span className="label">Nama (boleh dikosongkan)</span>
            <input
              className="input"
              value={nick}
              onChange={(e) => setNick(e.target.value)}
              maxLength={20}
              autoComplete="nickname"
              placeholder="Pemain"
            />
          </label>
          <button className="btn btn-primary btn-lg" type="submit" disabled={code.length !== 5}>
            Gabung
          </button>
        </form>
        <p id="kode-bantuan" className="muted small">
          Kode terdiri dari 5 huruf konsonan.
        </p>
      </main>
    );
  }

  // ----------------------------------------------------------- controller
  const ping = rtts.length > 0 ? Math.round(median(rtts)) : null;
  const ready = status === "open";
  return (
    <main className="controller">
      <header className="controller-head">
        {myId !== null && myId > 0 ? <PlayerBadge id={myId} size={40} /> : <span className="badge-empty" aria-hidden="true" />}
        <div className="grow">
          <div className="player-name">{nick.trim() || "Pemain"}</div>
          <div className="muted small">Kode {active}</div>
        </div>
        <button className="btn btn-ghost" onClick={leave}>
          Keluar
        </button>
      </header>

      <StatusBanner status={status} reason={reason} />

      <button
        className="pad"
        disabled={!ready}
        onPointerDown={(e) => {
          e.preventDefault();
          tap();
        }}
        onKeyDown={(e) => {
          if ((e.key === " " || e.key === "Enter") && !e.repeat) {
            e.preventDefault();
            tap();
          }
        }}
        aria-label="Ketuk"
      >
        {ready ? "KETUK" : "Menunggu sambungan…"}
      </button>

      <footer className="stats" aria-live="off">
        <span>Ketukanmu: {myTaps}</span>
        <span>{ping === null ? "Jeda: –" : `Jeda: ${ping} ms`}</span>
      </footer>
    </main>
  );
}

export default function JoinPage() {
  return (
    <Suspense fallback={<main className="page center">Memuat…</main>}>
      <Controller />
    </Suspense>
  );
}
````

### `apps/web/.env.example`

Hanya contoh isi variabel; nilai sebenarnya diisi di Vercel, bukan di file ini.

````
# Alamat relay (Worker Cloudflare). Isi di Vercel: Settings > Environment Variables.
# Tanpa garis miring di akhir.
NEXT_PUBLIC_RELAY_URL=https://game-relay.NAMA-AKUN-ANDA.workers.dev
````

