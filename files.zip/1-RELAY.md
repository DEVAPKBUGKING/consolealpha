# 1 · Relay (Cloudflare) — 5 file wajib, 2 file tes opsional

Salin ke repo dengan nama dan folder persis seperti judul tiap bagian.

Cara membuat tiap file di GitHub: **Add file → Create new file**, ketik nama file lengkap dengan folder (garis miring membuat folder otomatis), tempel isinya, lalu **Commit changes**. Kalau tampilan di HP menyulitkan, aktifkan *Desktop site* di browser.

### `apps/relay/package.json`

````json
{
  "name": "relay",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "wrangler dev",
    "deploy": "wrangler deploy",
    "test": "node --experimental-strip-types --test test/*.test.ts",
    "typecheck": "tsc --noEmit"
  },
  "devDependencies": {
    "@cloudflare/workers-types": "^4.20250101.0",
    "typescript": "^5.6.0",
    "wrangler": "^4.0.0"
  }
}
````

### `apps/relay/wrangler.jsonc`

````jsonc
{
  "$schema": "node_modules/wrangler/config-schema.json",
  // Nama ini HARUS sama persis dengan nama Worker di dashboard Cloudflare.
  "name": "game-relay",
  "main": "src/index.ts",
  "compatibility_date": "2025-09-01",
  "durable_objects": {
    "bindings": [{ "name": "ROOM", "class_name": "Room" }]
  },
  "migrations": [{ "tag": "v1", "new_sqlite_classes": ["Room"] }],
  "vars": {
    // Situs mana saja yang boleh memakai relay ini (dipisah koma). "*" hanya cocok satu label subdomain.
    // Sebelum rilis publik: ganti dengan domain Anda sendiri dan hapus https://*.vercel.app
    "ALLOWED_ORIGINS": "http://localhost:3000,https://*.vercel.app"
  },
  "observability": { "enabled": true }
}
````

### `apps/relay/tsconfig.json`

````json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "lib": ["ES2022"],
    "types": ["@cloudflare/workers-types"],
    "strict": true,
    "noEmit": true,
    "skipLibCheck": true,
    "allowImportingTsExtensions": true,
    "verbatimModuleSyntax": true
  },
  "include": ["src"]
}
````

### `apps/relay/src/core.ts`

````ts
// Inti relay: protokol + logika satu ruangan (sesi).
// Sengaja TIDAK mengimpor apa pun dari Cloudflare, supaya bisa diuji di Node.
// Adaptor Durable Object ada di index.ts.

// ---------------------------------------------------------------- konstanta

export const PROTOCOL_VERSION = 1;

// Kode sesi: 5 huruf konsonan saja. Tanpa vokal berarti tidak bisa membentuk kata
// (tidak ada kode yang tak sengaja jadi kata kasar), dan tanpa I/O/0/1 tidak ambigu.
export const CODE_ALPHABET = "BCDFGHJKLMNPQRSTVWXZ";
export const CODE_LENGTH = 5;

export const LIMITS = {
  maxMessageChars: 4096,
  maxControllers: 12, // controller yang tersambung bersamaan
  maxRegistered: 64, // total perangkat yang pernah mendaftar dalam satu sesi
  ratePerSec: 100,
  burst: 200,
  strikesToKick: 200,
  nicknameMax: 20,
  screenGraceMs: 10 * 60_000, // layar putus lebih dari ini: sesi dihapus
  idleMs: 2 * 60 * 60_000, // tidak ada pesan selama ini: sesi dihapus
  sweepMs: 5 * 60_000, // seberapa sering alarm memeriksa
  unjoinedMs: 30_000, // koneksi yang tidak kunjung hello ditutup
  touchPersistMs: 60_000,
} as const;

// Kode penutupan WebSocket (4000-4999 bebas dipakai aplikasi).
export const CLOSE = {
  replaced: 4000,
  notAllowed: 4003,
  rateLimited: 4008,
  full: 4009,
  expired: 4010,
  badHello: 4011,
} as const;

// ------------------------------------------------------------------ tipe

export type Role = "screen" | "controller";
export type DeviceInfo = { id: number; role: Role; nickname: string };

export type ClientHello = { t: "hello"; v?: number; role: Role; token?: string; nickname?: string };
export type ClientMsg = { t: "msg"; to: number | "all"; data: unknown };
export type ClientMessage = ClientHello | ClientMsg;

export type ServerMessage =
  | { t: "welcome"; v: number; device_id: number; device_token?: string; code: string; devices: DeviceInfo[] }
  | { t: "joined"; device: DeviceInfo }
  | { t: "left"; device_id: number }
  | { t: "msg"; from: number; data: unknown }
  | { t: "error"; code: string };

// ------------------------------------------------------------- utilitas

export function randomHex(bytes: number): string {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, "0")).join("");
}

// Memilih huruf tanpa bias: byte >= 240 dibuang (240 = 12 x 20).
export function generateCode(): string {
  const limit = 256 - (256 % CODE_ALPHABET.length);
  let out = "";
  while (out.length < CODE_LENGTH) {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    for (const b of buf) {
      if (b < limit && out.length < CODE_LENGTH) out += CODE_ALPHABET[b % CODE_ALPHABET.length];
    }
  }
  return out;
}

export function normalizeCode(input: unknown): string | null {
  if (typeof input !== "string") return null;
  const c = input.toUpperCase().replace(/[^A-Z]/g, "");
  if (c.length !== CODE_LENGTH) return null;
  for (const ch of c) if (!CODE_ALPHABET.includes(ch)) return null;
  return c;
}

// Membuang karakter kontrol dan karakter pengacak arah teks (dipakai untuk menyamar).
export function sanitizeNickname(input: unknown, fallback = "Pemain"): string {
  if (typeof input !== "string") return fallback;
  const cleaned = input
    .replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  const cut = Array.from(cleaned).slice(0, LIMITS.nicknameMax).join("").trim();
  return cut.length > 0 ? cut : fallback;
}

export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

// Daftar dipisah koma. Mendukung satu bintang untuk subdomain: https://*.vercel.app
export function originAllowed(origin: string | null, list: string): boolean {
  if (origin === null) return true; // bukan browser (curl, alat uji): CORS tidak berlaku
  for (const raw of list.split(",")) {
    const entry = raw.trim();
    if (!entry) continue;
    if (entry === "*") return true;
    const re = new RegExp("^" + entry.split("*").map((p) => p.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join("[^./]+") + "$");
    if (re.test(origin)) return true;
  }
  return false;
}

export class TokenBucket {
  tokens: number;
  last: number;
  strikes = 0;
  rate: number;
  burst: number;
  constructor(rate: number, burst: number, now: number) {
    this.rate = rate;
    this.burst = burst;
    this.tokens = burst;
    this.last = now;
  }
  take(now: number): boolean {
    this.tokens = Math.min(this.burst, this.tokens + ((now - this.last) / 1000) * this.rate);
    this.last = now;
    if (this.tokens >= 1) {
      this.tokens -= 1;
      if (this.tokens > this.burst / 2) this.strikes = 0;
      return true;
    }
    this.strikes += 1;
    return false;
  }
}

export function parseClientMessage(raw: unknown): { ok: true; msg: ClientMessage } | { ok: false; error: string } {
  if (typeof raw !== "string") return { ok: false, error: "bad_message" };
  if (raw.length > LIMITS.maxMessageChars) return { ok: false, error: "too_large" };
  let m: unknown;
  try {
    m = JSON.parse(raw);
  } catch {
    return { ok: false, error: "bad_message" };
  }
  if (typeof m !== "object" || m === null) return { ok: false, error: "bad_message" };
  const o = m as Record<string, unknown>;
  if (o.t === "hello") {
    if (o.role !== "screen" && o.role !== "controller") return { ok: false, error: "bad_message" };
    return {
      ok: true,
      msg: {
        t: "hello",
        v: typeof o.v === "number" ? o.v : undefined,
        role: o.role,
        token: typeof o.token === "string" ? o.token : undefined,
        nickname: typeof o.nickname === "string" ? o.nickname : undefined,
      },
    };
  }
  if (o.t === "msg") {
    const to = o.to;
    if (to !== "all" && !(typeof to === "number" && Number.isInteger(to) && to >= 0)) {
      return { ok: false, error: "bad_message" };
    }
    return { ok: true, msg: { t: "msg", to, data: o.data === undefined ? null : o.data } };
  }
  return { ok: false, error: "unknown_type" };
}

// ------------------------------------------------------ logika ruangan

export type Attachment = { deviceId: number | null; role: Role | null; openedAt: number };

export interface Conn {
  send(data: string): void;
  close(code: number, reason: string): void;
  getAttachment(): Attachment | null;
  setAttachment(a: Attachment): void;
  isOpen(): boolean;
}
export interface Store {
  get<T>(key: string): Promise<T | undefined>;
  put(key: string, value: unknown): Promise<void>;
  deleteAll(): Promise<void>;
}
export interface Host {
  conns(): Conn[];
  now(): number;
}

type Meta = {
  code: string;
  hostToken: string;
  createdAt: number;
  nextDeviceId: number;
  screenLeftAt: number | null;
  lastActive: number;
};
type Devices = Record<string, { token: string; nickname: string }>;
type Online = { conn: Conn; id: number; role: Role };

export class RoomCore {
  store: Store;
  host: Host;
  buckets = new Map<number, TokenBucket>();
  lastWarn = new Map<number, number>();
  lastActiveMem = 0;
  lastPersist = 0;

  constructor(store: Store, host: Host) {
    this.store = store;
    this.host = host;
  }

  async create(code: string): Promise<{ ok: true; hostToken: string } | { ok: false }> {
    if (await this.store.get<Meta>("meta")) return { ok: false };
    const now = this.host.now();
    const meta: Meta = {
      code,
      hostToken: randomHex(16),
      createdAt: now,
      nextDeviceId: 1,
      screenLeftAt: now, // layar belum pernah tersambung: hitung sebagai "baru putus"
      lastActive: now,
    };
    await this.store.put("meta", meta);
    await this.store.put("devices", {});
    this.lastActiveMem = now;
    this.lastPersist = now;
    return { ok: true, hostToken: meta.hostToken };
  }

  async info(): Promise<{ exists: boolean; screen?: boolean; controllers?: number }> {
    const meta = await this.store.get<Meta>("meta");
    if (!meta) return { exists: false };
    const on = this.online();
    return {
      exists: true,
      screen: on.some((d) => d.id === 0),
      controllers: on.filter((d) => d.role === "controller").length,
    };
  }

  onOpen(conn: Conn): void {
    conn.setAttachment({ deviceId: null, role: null, openedAt: this.host.now() });
  }

  async onMessage(conn: Conn, raw: unknown): Promise<void> {
    const parsed = parseClientMessage(raw);
    if (!parsed.ok) return this.error(conn, parsed.error);
    const m = parsed.msg;
    if (m.t === "hello") return this.hello(conn, m);

    const att = conn.getAttachment();
    if (!att || att.deviceId === null) return this.error(conn, "not_joined");
    const id = att.deviceId;
    if (!this.allow(conn, id)) return;

    await this.touch();
    const out = JSON.stringify({ t: "msg", from: id, data: m.data } satisfies ServerMessage);
    if (m.to === "all") {
      for (const d of this.online()) if (d.conn !== conn) d.conn.send(out);
      return;
    }
    const target = this.online().find((d) => d.id === m.to && d.conn !== conn);
    if (!target) return this.error(conn, "not_found");
    target.conn.send(out);
  }

  async onClose(conn: Conn): Promise<void> {
    const att = conn.getAttachment();
    if (!att || att.deviceId === null) return;
    const id = att.deviceId;
    // Sudah digantikan koneksi baru dengan id yang sama: bukan "keluar" sungguhan.
    if (this.online().some((d) => d.conn !== conn && d.id === id)) return;
    this.broadcast({ t: "left", device_id: id }, conn);
    if (id === 0) {
      const meta = await this.store.get<Meta>("meta");
      if (meta) {
        meta.screenLeftAt = this.host.now();
        await this.store.put("meta", meta);
      }
    }
  }

  // Dipanggil alarm secara berkala. "expired" berarti seluruh data sudah dihapus.
  async sweep(): Promise<"keep" | "expired"> {
    const meta = await this.store.get<Meta>("meta");
    const now = this.host.now();
    if (!meta) return "expired";
    const screenOn = this.online().some((d) => d.id === 0);
    const lastActive = Math.max(meta.lastActive, this.lastActiveMem);
    const noScreen = !screenOn && meta.screenLeftAt !== null && now - meta.screenLeftAt > LIMITS.screenGraceMs;
    const idle = now - lastActive > LIMITS.idleMs;
    if (noScreen || idle) {
      for (const c of this.host.conns()) c.close(CLOSE.expired, "expired");
      await this.store.deleteAll();
      return "expired";
    }
    for (const c of this.host.conns()) {
      const a = c.getAttachment();
      if (a && a.deviceId === null && now - a.openedAt > LIMITS.unjoinedMs) c.close(CLOSE.badHello, "no_hello");
    }
    return "keep";
  }

  // ------------------------------------------------------------ privat

  private async hello(conn: Conn, m: ClientHello): Promise<void> {
    const att = conn.getAttachment();
    if (att && att.deviceId !== null) return this.error(conn, "already_joined");
    const meta = await this.store.get<Meta>("meta");
    if (!meta) {
      this.error(conn, "not_found");
      conn.close(CLOSE.expired, "expired");
      return;
    }
    const devices = (await this.store.get<Devices>("devices")) ?? {};
    const nickname = sanitizeNickname(m.nickname);
    let id: number;
    let token: string | undefined;

    if (m.role === "screen") {
      if (typeof m.token !== "string" || !safeEqual(m.token, meta.hostToken)) {
        this.error(conn, "not_allowed");
        conn.close(CLOSE.notAllowed, "not_allowed");
        return;
      }
      id = 0;
      meta.screenLeftAt = null;
    } else {
      let existing: string | undefined;
      if (typeof m.token === "string") {
        const given = m.token;
        existing = Object.keys(devices).find((k) => safeEqual(devices[k].token, given));
      }
      if (existing !== undefined) {
        id = Number(existing);
        token = m.token;
      } else {
        const online = this.online().filter((d) => d.conn !== conn && d.role === "controller").length;
        if (online >= LIMITS.maxControllers || Object.keys(devices).length >= LIMITS.maxRegistered) {
          this.error(conn, "full");
          conn.close(CLOSE.full, "full");
          return;
        }
        id = meta.nextDeviceId;
        meta.nextDeviceId += 1;
        token = randomHex(16);
      }
      devices[String(id)] = { token: token as string, nickname };
    }

    for (const d of this.online()) if (d.conn !== conn && d.id === id) d.conn.close(CLOSE.replaced, "replaced");
    conn.setAttachment({ deviceId: id, role: m.role, openedAt: att ? att.openedAt : this.host.now() });

    meta.lastActive = this.host.now();
    this.lastActiveMem = meta.lastActive;
    this.lastPersist = meta.lastActive;
    await this.store.put("meta", meta);
    if (m.role === "controller") await this.store.put("devices", devices);

    const list = new Map<number, DeviceInfo>();
    for (const d of this.online()) {
      list.set(d.id, { id: d.id, role: d.role, nickname: d.id === 0 ? "" : devices[String(d.id)]?.nickname ?? "" });
    }
    this.send(conn, {
      t: "welcome",
      v: PROTOCOL_VERSION,
      device_id: id,
      device_token: token,
      code: meta.code,
      devices: Array.from(list.values()),
    });
    this.broadcast({ t: "joined", device: list.get(id) as DeviceInfo }, conn);
  }

  private online(): Online[] {
    const out: Online[] = [];
    for (const conn of this.host.conns()) {
      if (!conn.isOpen()) continue;
      const a = conn.getAttachment();
      if (a && a.deviceId !== null && a.role) out.push({ conn, id: a.deviceId, role: a.role });
    }
    return out;
  }

  private allow(conn: Conn, id: number): boolean {
    const now = this.host.now();
    let b = this.buckets.get(id);
    if (!b) {
      b = new TokenBucket(LIMITS.ratePerSec, LIMITS.burst, now);
      this.buckets.set(id, b);
    }
    if (b.take(now)) return true;
    if (b.strikes >= LIMITS.strikesToKick) {
      this.error(conn, "rate_limited");
      conn.close(CLOSE.rateLimited, "rate_limited");
      return false;
    }
    const lw = this.lastWarn.get(id) ?? 0;
    if (now - lw > 1000) {
      this.lastWarn.set(id, now);
      this.error(conn, "rate_limited");
    }
    return false;
  }

  // Catat aktivitas di memori; tulis ke penyimpanan paling sering sekali per menit.
  private async touch(): Promise<void> {
    const now = this.host.now();
    this.lastActiveMem = now;
    if (now - this.lastPersist < LIMITS.touchPersistMs) return;
    this.lastPersist = now;
    const meta = await this.store.get<Meta>("meta");
    if (meta) {
      meta.lastActive = now;
      await this.store.put("meta", meta);
    }
  }

  private send(conn: Conn, msg: ServerMessage): void {
    conn.send(JSON.stringify(msg));
  }

  private error(conn: Conn, code: string): void {
    this.send(conn, { t: "error", code });
  }

  private broadcast(msg: ServerMessage, except: Conn): void {
    const out = JSON.stringify(msg);
    for (const d of this.online()) if (d.conn !== except) d.conn.send(out);
  }
}
````

### `apps/relay/src/index.ts`

````ts
// Relay realtime: Worker (pintu masuk HTTP) + Durable Object "Room" (satu per kode sesi).
// Seluruh logika ada di core.ts; file ini hanya menyambungkannya ke Cloudflare.
import { DurableObject } from "cloudflare:workers";
import { LIMITS, RoomCore, generateCode, normalizeCode, originAllowed } from "./core.ts";
import type { Attachment, Conn, Store } from "./core.ts";

export interface Env {
  ROOM: DurableObjectNamespace<Room>;
  ALLOWED_ORIGINS: string;
}

// ------------------------------------------------------------ Durable Object

export class Room extends DurableObject<Env> {
  core: RoomCore;
  wrapped = new WeakMap<WebSocket, Conn>();

  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    const store: Store = {
      get: <T>(k: string) => ctx.storage.get<T>(k),
      put: (k, v) => ctx.storage.put(k, v),
      deleteAll: () => ctx.storage.deleteAll(),
    };
    this.core = new RoomCore(store, {
      conns: () => ctx.getWebSockets().map((ws) => this.wrap(ws)),
      now: () => Date.now(),
    });
    // "ping" dari klien dijawab "pong" oleh runtime TANPA membangunkan objek ini.
    ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair("ping", "pong"));
  }

  // Satu pembungkus per WebSocket, supaya perbandingan identitas (===) di core.ts benar.
  wrap(ws: WebSocket): Conn {
    let c = this.wrapped.get(ws);
    if (c) return c;
    c = {
      send: (d) => {
        try {
          ws.send(d);
        } catch {}
      },
      close: (code, reason) => {
        try {
          ws.close(code, reason);
        } catch {}
      },
      getAttachment: () => ws.deserializeAttachment() as Attachment | null,
      setAttachment: (a) => ws.serializeAttachment(a),
      isOpen: () => ws.readyState === 1,
    };
    this.wrapped.set(ws, c);
    return c;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/init" && request.method === "POST") {
      const { code } = (await request.json()) as { code: string };
      const r = await this.core.create(code);
      if (!r.ok) return new Response("taken", { status: 409 });
      await this.ctx.storage.setAlarm(Date.now() + LIMITS.sweepMs);
      return Response.json({ host_token: r.hostToken });
    }

    if (url.pathname === "/info") return Response.json(await this.core.info());

    if (url.pathname.startsWith("/v1/ws/") && request.headers.get("Upgrade") === "websocket") {
      const info = await this.core.info();
      if (!info.exists) return new Response("not found", { status: 404 });
      const pair = new WebSocketPair();
      const [client, server] = Object.values(pair);
      this.ctx.acceptWebSocket(server);
      this.core.onOpen(this.wrap(server));
      return new Response(null, { status: 101, webSocket: client });
    }

    return new Response("not found", { status: 404 });
  }

  async webSocketMessage(ws: WebSocket, message: string | ArrayBuffer): Promise<void> {
    await this.core.onMessage(this.wrap(ws), message);
  }

  async webSocketClose(ws: WebSocket, code: number): Promise<void> {
    try {
      ws.close(code >= 1000 && code < 5000 && code !== 1005 && code !== 1006 ? code : 1000, "bye");
    } catch {}
    await this.core.onClose(this.wrap(ws));
  }

  async webSocketError(ws: WebSocket): Promise<void> {
    await this.core.onClose(this.wrap(ws));
  }

  async alarm(): Promise<void> {
    const r = await this.core.sweep();
    if (r === "keep") await this.ctx.storage.setAlarm(Date.now() + LIMITS.sweepMs);
  }
}

// -------------------------------------------------------------------- Worker

// Pembatas laju sederhana per isolate Worker. Ini "usaha terbaik": setiap isolate punya
// hitungan sendiri. Pembatas sungguhan (aturan rate limiting Cloudflare) butuh domain
// terdaftar di Cloudflare dan ditambahkan setelah pindah DNS.
const hits = new Map<string, { n: number; reset: number }>();
function limited(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  if (hits.size > 5000) hits.clear();
  const h = hits.get(key);
  if (!h || now > h.reset) {
    hits.set(key, { n: 1, reset: now + windowMs });
    return false;
  }
  h.n += 1;
  return h.n > max;
}

function json(body: unknown, status: number, cors: Record<string, string>): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", ...cors },
  });
}

function corsFor(request: Request, env: Env): Record<string, string> | null {
  const origin = request.headers.get("Origin");
  if (!originAllowed(origin, env.ALLOWED_ORIGINS)) return null;
  if (!origin) return {};
  return {
    "access-control-allow-origin": origin,
    vary: "Origin",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-max-age": "86400",
  };
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const cors = corsFor(request, env);
    if (cors === null) return new Response("origin not allowed", { status: 403 });
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    const room = (code: string) => env.ROOM.get(env.ROOM.idFromName(code));

    if (url.pathname === "/health") return json({ ok: true }, 200, cors);

    // Buat sesi baru
    if (url.pathname === "/v1/sessions" && request.method === "POST") {
      if (limited("create:" + ip, 10, 60_000)) return json({ error: "rate_limited" }, 429, cors);
      for (let i = 0; i < 8; i++) {
        const code = generateCode();
        const r = await room(code).fetch("https://room/init", { method: "POST", body: JSON.stringify({ code }) });
        if (r.status === 200) {
          const { host_token } = (await r.json()) as { host_token: string };
          return json({ code, host_token }, 200, cors);
        }
        if (r.status !== 409) break; // 409 = kode sudah dipakai: coba kode lain
      }
      return json({ error: "unavailable" }, 503, cors);
    }

    // Cek apakah kode ada
    const info = url.pathname.match(/^\/v1\/sessions\/([A-Za-z]+)$/);
    if (info && request.method === "GET") {
      if (limited("info:" + ip, 120, 60_000)) return json({ error: "rate_limited" }, 429, cors);
      const code = normalizeCode(info[1]);
      if (!code) return json({ exists: false }, 200, cors);
      const r = await room(code).fetch("https://room/info");
      return json(await r.json(), 200, cors);
    }

    // Sambungan WebSocket
    const ws = url.pathname.match(/^\/v1\/ws\/([A-Za-z]+)$/);
    if (ws && request.headers.get("Upgrade") === "websocket") {
      if (limited("ws:" + ip, 120, 60_000)) return new Response("rate limited", { status: 429 });
      const code = normalizeCode(ws[1]);
      if (!code) return new Response("not found", { status: 404 });
      return room(code).fetch(request);
    }

    return json({ error: "not_found" }, 404, cors);
  },
};
````

---

## Opsional: tes otomatis

Tidak dibutuhkan untuk deploy. Berguna nanti bila Anda menjalankannya di laptop (`npm test`): 33 tes untuk logika relay dan kontrak klien-relay.

### `apps/relay/test/core.test.ts`

````ts
// Jalankan: npm test   (Node 22.6 ke atas)
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  CLOSE,
  CODE_ALPHABET,
  CODE_LENGTH,
  LIMITS,
  RoomCore,
  TokenBucket,
  generateCode,
  normalizeCode,
  originAllowed,
  parseClientMessage,
  sanitizeNickname,
} from "../src/core.ts";
import type { Attachment, Conn, Host, Store } from "../src/core.ts";

// ------------------------------------------------------------ tiruan

class FakeConn implements Conn {
  att: Attachment | null = null;
  open = true;
  inbox: any[] = [];
  closed: { code: number; reason: string } | null = null;
  send(d: string) {
    this.inbox.push(JSON.parse(d));
  }
  close(code: number, reason: string) {
    this.open = false;
    this.closed = { code, reason };
  }
  getAttachment() {
    return this.att;
  }
  setAttachment(a: Attachment) {
    this.att = a;
  }
  isOpen() {
    return this.open;
  }
  last(t: string) {
    return [...this.inbox].reverse().find((m) => m.t === t);
  }
  all(t: string) {
    return this.inbox.filter((m) => m.t === t);
  }
}

class FakeStore implements Store {
  m = new Map<string, unknown>();
  async get<T>(k: string) {
    return this.m.has(k) ? (structuredClone(this.m.get(k)) as T) : undefined;
  }
  async put(k: string, v: unknown) {
    this.m.set(k, structuredClone(v));
  }
  async deleteAll() {
    this.m.clear();
  }
}

function setup() {
  const store = new FakeStore();
  const conns: FakeConn[] = [];
  const clock = { now: 1_000_000 };
  const host: Host = { conns: () => conns, now: () => clock.now };
  const core = new RoomCore(store, host);
  const connect = () => {
    const c = new FakeConn();
    conns.push(c);
    core.onOpen(c);
    return c;
  };
  const send = (c: FakeConn, o: unknown) => core.onMessage(c, JSON.stringify(o));
  return { store, conns, clock, core, connect, send };
}

async function withSession() {
  const s = setup();
  const created = await s.core.create("BCDFG");
  assert.equal(created.ok, true);
  const hostToken = (created as { ok: true; hostToken: string }).hostToken;
  const screen = s.connect();
  await s.send(screen, { t: "hello", role: "screen", token: hostToken });
  return { ...s, hostToken, screen };
}

// ------------------------------------------------------- utilitas murni

test("generateCode: panjang dan huruf sesuai alfabet, tanpa vokal", () => {
  for (let i = 0; i < 500; i++) {
    const c = generateCode();
    assert.equal(c.length, CODE_LENGTH);
    for (const ch of c) assert.ok(CODE_ALPHABET.includes(ch));
    assert.doesNotMatch(c, /[AEIOUY]/);
  }
});

test("normalizeCode", () => {
  assert.equal(normalizeCode(" bcd fg "), "BCDFG");
  assert.equal(normalizeCode("BCDF"), null);
  assert.equal(normalizeCode("BCDFA"), null); // vokal tidak ada di alfabet
  assert.equal(normalizeCode(123), null);
});

test("sanitizeNickname", () => {
  assert.equal(sanitizeNickname("  Dewi   Sari "), "Dewi Sari");
  assert.equal(sanitizeNickname("a\u202eb\u0000c"), "abc");
  assert.equal(sanitizeNickname(""), "Pemain");
  assert.equal(sanitizeNickname(undefined), "Pemain");
  assert.equal(Array.from(sanitizeNickname("x".repeat(50))).length, LIMITS.nicknameMax);
});

test("originAllowed", () => {
  const list = "http://localhost:3000,https://*.vercel.app";
  assert.ok(originAllowed("http://localhost:3000", list));
  assert.ok(originAllowed("https://abc-git-main-me.vercel.app", list));
  assert.ok(!originAllowed("https://evil.com", list));
  assert.ok(!originAllowed("https://vercel.app.evil.com", list));
  assert.ok(!originAllowed("https://a.b.vercel.app", list)); // satu label saja
  assert.ok(originAllowed(null, list));
});

test("TokenBucket: burst lalu terbatas lalu pulih", () => {
  const b = new TokenBucket(10, 5, 0);
  for (let i = 0; i < 5; i++) assert.ok(b.take(0));
  assert.ok(!b.take(0));
  assert.ok(b.take(200)); // 2 token pulih
});

test("parseClientMessage menolak yang aneh", () => {
  assert.deepEqual(parseClientMessage("{"), { ok: false, error: "bad_message" });
  assert.deepEqual(parseClientMessage(JSON.stringify({ t: "x" })), { ok: false, error: "unknown_type" });
  assert.deepEqual(parseClientMessage(JSON.stringify({ t: "msg", to: -1 })), { ok: false, error: "bad_message" });
  assert.deepEqual(parseClientMessage("x".repeat(5000)), { ok: false, error: "too_large" });
  assert.deepEqual(parseClientMessage(new ArrayBuffer(2)), { ok: false, error: "bad_message" });
});

// ---------------------------------------------------------- alur ruangan

test("create: kode yang sama tidak bisa dibuat dua kali", async () => {
  const { core } = setup();
  assert.equal((await core.create("BCDFG")).ok, true);
  assert.equal((await core.create("BCDFG")).ok, false);
  assert.deepEqual(await core.info(), { exists: true, screen: false, controllers: 0 });
});

test("layar dengan token salah ditolak dan ditutup", async () => {
  const { core, connect, send } = setup();
  await core.create("BCDFG");
  const c = connect();
  await send(c, { t: "hello", role: "screen", token: "salah" });
  assert.equal(c.last("error").code, "not_allowed");
  assert.equal(c.closed?.code, CLOSE.notAllowed);
});

test("layar bergabung sebagai id 0, controller dapat id 1 dan token", async () => {
  const { connect, send, screen } = await withSession();
  assert.equal(screen.last("welcome").device_id, 0);
  const a = connect();
  await send(a, { t: "hello", role: "controller", nickname: "Dewi" });
  const w = a.last("welcome");
  assert.equal(w.device_id, 1);
  assert.equal(typeof w.device_token, "string");
  assert.equal(w.code, "BCDFG");
  assert.deepEqual(screen.last("joined").device, { id: 1, role: "controller", nickname: "Dewi" });
});

test("pesan controller ke layar dan sebaliknya membawa 'from' yang benar", async () => {
  const { connect, send, screen } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  await send(a, { t: "msg", to: 0, data: { k: "tap" } });
  assert.deepEqual(screen.last("msg"), { t: "msg", from: 1, data: { k: "tap" } });
  await send(screen, { t: "msg", to: 1, data: { k: "ack" } });
  assert.deepEqual(a.last("msg"), { t: "msg", from: 0, data: { k: "ack" } });
});

test("'from' tidak bisa dipalsukan oleh pengirim", async () => {
  const { connect, send, screen } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  await core_send_raw(a, send, { t: "msg", to: 0, data: 1, from: 99 });
  assert.equal(screen.last("msg").from, 1);
});
async function core_send_raw(c: FakeConn, send: (c: FakeConn, o: unknown) => Promise<void>, o: unknown) {
  await send(c, o);
}

test("broadcast 'all' tidak kembali ke pengirim", async () => {
  const { connect, send, screen } = await withSession();
  const a = connect();
  const b = connect();
  await send(a, { t: "hello", role: "controller" });
  await send(b, { t: "hello", role: "controller" });
  await send(a, { t: "msg", to: "all", data: "halo" });
  assert.equal(b.all("msg").length, 1);
  assert.equal(screen.all("msg").length, 1);
  assert.equal(a.all("msg").length, 0);
});

test("tujuan yang tidak ada: error not_found ke pengirim saja", async () => {
  const { connect, send } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  await send(a, { t: "msg", to: 42, data: 1 });
  assert.equal(a.last("error").code, "not_found");
});

test("sebelum hello, pesan ditolak", async () => {
  const { connect, send } = await withSession();
  const a = connect();
  await send(a, { t: "msg", to: 0, data: 1 });
  assert.equal(a.last("error").code, "not_joined");
});

test("sambung ulang dengan token mempertahankan id; koneksi lama digantikan tanpa 'left'", async () => {
  const { connect, send, screen, core } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller", nickname: "Dewi" });
  const token = a.last("welcome").device_token;
  const a2 = connect();
  await send(a2, { t: "hello", role: "controller", token, nickname: "Dewi" });
  assert.equal(a2.last("welcome").device_id, 1);
  assert.equal(a.closed?.code, CLOSE.replaced);
  await core.onClose(a); // penutupan koneksi lama baru terdeteksi belakangan
  assert.equal(screen.all("left").length, 0);
  assert.equal((await core.info()).controllers, 1);
});

test("controller keluar: layar menerima 'left'", async () => {
  const { connect, send, screen, core } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  a.open = false;
  await core.onClose(a);
  assert.deepEqual(screen.last("left"), { t: "left", device_id: 1 });
});

test("layar baru dengan host token menggantikan layar lama", async () => {
  const { connect, send, screen, hostToken, core } = await withSession();
  const s2 = connect();
  await send(s2, { t: "hello", role: "screen", token: hostToken });
  assert.equal(screen.closed?.code, CLOSE.replaced);
  await core.onClose(screen);
  assert.equal((await core.info()).screen, true);
});

test("batas controller bersamaan: yang ke-13 ditolak", async () => {
  const { connect, send } = await withSession();
  for (let i = 0; i < LIMITS.maxControllers; i++) {
    const c = connect();
    await send(c, { t: "hello", role: "controller" });
    assert.equal(c.last("welcome").device_id, i + 1);
  }
  const extra = connect();
  await send(extra, { t: "hello", role: "controller" });
  assert.equal(extra.last("error").code, "full");
  assert.equal(extra.closed?.code, CLOSE.full);
});

test("batas laju: lewat burst ditolak, terus-menerus diputus", async () => {
  const { connect, send, screen } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  let delivered = 0;
  for (let i = 0; i < LIMITS.burst + 50; i++) await send(a, { t: "msg", to: 0, data: i });
  delivered = screen.all("msg").length;
  assert.equal(delivered, LIMITS.burst);
  assert.equal(a.last("error").code, "rate_limited");
  for (let i = 0; i < LIMITS.strikesToKick + 10; i++) await send(a, { t: "msg", to: 0, data: i });
  assert.equal(a.closed?.code, CLOSE.rateLimited);
});

test("pesan terlalu besar ditolak tanpa memutus koneksi", async () => {
  const { connect, send } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  await send(a, { t: "msg", to: 0, data: "x".repeat(5000) });
  assert.equal(a.last("error").code, "too_large");
  assert.equal(a.closed, null);
});

test("sweep: sesi tanpa layar lebih dari 10 menit dihapus", async () => {
  const s = setup();
  await s.core.create("BCDFG");
  assert.equal(await s.core.sweep(), "keep");
  s.clock.now += LIMITS.screenGraceMs + 1;
  assert.equal(await s.core.sweep(), "expired");
  assert.deepEqual(await s.core.info(), { exists: false });
});

test("sweep: sesi dengan layar tersambung tapi diam 2 jam dihapus", async () => {
  const { clock, core, conns } = await withSession();
  clock.now += LIMITS.idleMs - 1000;
  assert.equal(await core.sweep(), "keep");
  clock.now += 2000;
  assert.equal(await core.sweep(), "expired");
  assert.ok(conns.every((c) => c.closed?.code === CLOSE.expired));
});

test("sweep: aktivitas pesan memperpanjang sesi", async () => {
  const { clock, core, connect, send } = await withSession();
  const a = connect();
  await send(a, { t: "hello", role: "controller" });
  clock.now += LIMITS.idleMs - 1000;
  await send(a, { t: "msg", to: 0, data: 1 });
  clock.now += LIMITS.idleMs - 1000;
  assert.equal(await core.sweep(), "keep");
});

test("sweep: koneksi yang tidak kunjung hello ditutup", async () => {
  const { clock, core, connect } = await withSession();
  const lonely = connect();
  clock.now += LIMITS.unjoinedMs + 1;
  await core.sweep();
  assert.equal(lonely.closed?.code, CLOSE.badHello);
});
````

### `apps/relay/test/integration.test.ts`

````ts
// Menguji kontrak klien web (apps/web/lib/link.ts) terhadap logika relay (src/core.ts)
// lewat WebSocket tiruan di memori. Tidak butuh jaringan atau Cloudflare.
import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import { CLOSE, LIMITS, RoomCore } from "../src/core.ts";
import type { Attachment, Conn, Store } from "../src/core.ts";
import { LinkClient } from "../../web/lib/link.ts";
import type { LinkStatus, CloseReason } from "../../web/lib/link.ts";

// ---------------------------------------------------------------- dunia tiruan

class MemStore implements Store {
  m = new Map<string, unknown>();
  async get<T>(k: string) {
    return this.m.has(k) ? (structuredClone(this.m.get(k)) as T) : undefined;
  }
  async put(k: string, v: unknown) {
    this.m.set(k, structuredClone(v));
  }
  async deleteAll() {
    this.m.clear();
  }
}

class Srv implements Conn {
  att: Attachment | null = null;
  open = true;
  client: FakeWS;
  net: Net;
  constructor(net: Net, client: FakeWS) {
    this.net = net;
    this.client = client;
  }
  send(d: string) {
    setTimeout(() => {
      if (this.open && !this.net.mute) this.client.onmessage?.({ data: d } as MessageEvent);
    }, 0);
  }
  close(code: number) {
    if (!this.open) return;
    this.open = false;
    this.client.readyState = 3;
    setTimeout(() => this.client.onclose?.({ code } as CloseEvent), 0);
    void this.net.core.onClose(this);
  }
  getAttachment() {
    return this.att;
  }
  setAttachment(a: Attachment) {
    this.att = a;
  }
  isOpen() {
    return this.open;
  }
}

class Net {
  core: RoomCore;
  srvs: Srv[] = [];
  mute = false; // true = server tidak membalas apa pun (koneksi "mati")
  offline = false;
  now = Date.now();
  constructor() {
    this.core = new RoomCore(new MemStore(), { conns: () => this.srvs, now: () => this.now });
  }
  ws = (net: Net) =>
    class extends FakeWS {
      constructor(url: string) {
        super(net, url);
      }
    };
}

class FakeWS {
  readyState = 0;
  onopen: (() => void) | null = null;
  onmessage: ((e: MessageEvent) => void) | null = null;
  onclose: ((e: CloseEvent) => void) | null = null;
  onerror: (() => void) | null = null;
  srv: Srv | null = null;
  net: Net;
  constructor(net: Net, _url: string) {
    this.net = net;
    setTimeout(() => {
      if (net.offline) {
        this.readyState = 3;
        this.onclose?.({ code: 1006 } as CloseEvent);
        return;
      }
      this.srv = new Srv(net, this);
      net.srvs.push(this.srv);
      net.core.onOpen(this.srv);
      this.readyState = 1;
      this.onopen?.();
    }, 0);
  }
  send(d: string) {
    if (this.readyState !== 1 || !this.srv || this.net.mute) return;
    const srv = this.srv;
    setTimeout(() => {
      if (!srv.open) return;
      if (d === "ping") this.onmessage?.({ data: "pong" } as MessageEvent);
      else void this.net.core.onMessage(srv, d);
    }, 0);
  }
  close() {
    if (this.readyState === 3) return;
    this.readyState = 3;
    if (this.srv && this.srv.open) {
      this.srv.open = false;
      void this.net.core.onClose(this.srv);
    }
  }
  // Putus mendadak tanpa kode penutupan resmi (Wi-Fi hilang).
  yank() {
    this.readyState = 3;
    if (this.srv) this.srv.open = false;
    setTimeout(() => this.onclose?.({ code: 1006 } as CloseEvent), 0);
    if (this.srv) void this.net.core.onClose(this.srv);
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function until(cond: () => boolean, what: string, ms = 2000) {
  const t0 = Date.now();
  while (!cond()) {
    if (Date.now() - t0 > ms) assert.fail("timeout menunggu: " + what);
    await sleep(2);
  }
}

function fetchFor(net: Net): typeof fetch {
  return (async (url: string) => {
    if (net.offline) throw new Error("offline");
    const code = String(url).split("/").pop();
    const info = code === "BCDFG" ? await net.core.info() : { exists: false };
    return { ok: true, json: async () => info } as Response;
  }) as unknown as typeof fetch;
}

// Semua klien yang dibuat tes dihentikan di akhir tiap tes, supaya tidak ada timer yang tersisa.
const created: LinkClient[] = [];
afterEach(() => {
  for (const c of created.splice(0)) c.stop();
});

type Track = { status: LinkStatus; reason?: CloseReason; msgs: { from: number; data: any }[]; joined: number[]; left: number[] };
function client(net: Net, role: "screen" | "controller", token: string | undefined, extra: Record<string, unknown> = {}) {
  const t: Track = { status: "connecting", msgs: [], joined: [], left: [] };
  const link = new LinkClient({
    relayUrl: "https://relay.test",
    code: "BCDFG",
    role,
    token,
    nickname: role === "controller" ? "Dewi" : undefined,
    onStatus: (s, r) => {
      t.status = s;
      t.reason = r;
    },
    onMessage: (from, data) => t.msgs.push({ from, data }),
    onJoined: (d) => t.joined.push(d.id),
    onLeft: (id) => t.left.push(id),
    WebSocketImpl: net.ws(net) as unknown as typeof WebSocket,
    fetchImpl: fetchFor(net),
    backoffBaseMs: 5,
    pingMs: 20,
    ...extra,
  });
  created.push(link);
  return { link, t };
}

async function boot() {
  const net = new Net();
  const created = await net.core.create("BCDFG");
  assert.ok(created.ok);
  const hostToken = (created as { ok: true; hostToken: string }).hostToken;
  const screen = client(net, "screen", hostToken);
  screen.link.start();
  await until(() => screen.t.status === "open", "layar terhubung");
  return { net, hostToken, screen };
}

// ----------------------------------------------------------------------- tes

test("vertical slice: tap dari HP sampai ack kembali", async () => {
  const { net, screen } = await boot();
  const phone = client(net, "controller", undefined);
  phone.link.start();
  await until(() => phone.t.status === "open", "HP terhubung");
  assert.equal(phone.link.deviceId, 1);
  await until(() => screen.t.joined.includes(1), "layar melihat HP bergabung");

  assert.ok(phone.link.send(0, { k: "tap", ts: 123 }));
  await until(() => screen.t.msgs.length === 1, "layar menerima tap");
  assert.deepEqual(screen.t.msgs[0], { from: 1, data: { k: "tap", ts: 123 } });

  assert.ok(screen.link.send(1, { k: "ack", ts: 123 }));
  await until(() => phone.t.msgs.length === 1, "HP menerima ack");
  assert.deepEqual(phone.t.msgs[0], { from: 0, data: { k: "ack", ts: 123 } });

  phone.link.stop();
  screen.link.stop();
});

test("putus mendadak: HP sambung ulang otomatis dengan id yang sama", async () => {
  const { net, screen } = await boot();
  const phone = client(net, "controller", undefined);
  phone.link.start();
  await until(() => phone.t.status === "open", "HP terhubung");
  const idBefore = phone.link.deviceId;
  const firstWs = (phone.link as any).ws as FakeWS;

  firstWs.yank();
  await until(() => phone.t.status === "reconnecting", "HP sadar putus");
  await until(() => phone.t.status === "open" && phone.link.deviceId !== null, "HP tersambung lagi");
  assert.equal(phone.link.deviceId, idBefore);
  await until(() => screen.t.left.includes(1) && screen.t.joined.filter((i) => i === 1).length >= 2, "layar melihat keluar lalu masuk");

  assert.ok(phone.link.send(0, "setelah-sambung-ulang"));
  await until(() => screen.t.msgs.some((m) => m.data === "setelah-sambung-ulang"), "pesan tiba");
  phone.link.stop();
  screen.link.stop();
});

test("layar dengan host token salah berhenti dengan alasan not_allowed", async () => {
  const net = new Net();
  await net.core.create("BCDFG");
  const bad = client(net, "screen", "tebakan");
  bad.link.start();
  await until(() => bad.t.status === "closed", "ditolak");
  assert.equal(bad.t.reason, "not_allowed");
});

test("kode yang tidak ada: berhenti dengan alasan not_found", async () => {
  const net = new Net();
  const c = client(net, "controller", undefined);
  c.link.start(); // sesi belum dibuat
  await until(() => c.t.status === "closed", "kode tidak ditemukan");
  assert.equal(c.t.reason, "not_found");
});

test("tab lain memakai token yang sama: yang lama berhenti dengan alasan replaced", async () => {
  const { net } = await boot();
  const a = client(net, "controller", undefined);
  a.link.start();
  await until(() => a.t.status === "open", "A terhubung");
  const token = (a.link.opts as any).token as string;
  assert.ok(token);
  const b = client(net, "controller", token);
  b.link.start();
  await until(() => b.t.status === "open", "B terhubung");
  await until(() => a.t.status === "closed", "A digantikan");
  assert.equal(a.t.reason, "replaced");
  assert.equal(b.link.deviceId, a.link.deviceId ?? 1);
  b.link.stop();
});

test("sesi kedaluwarsa: semua klien berhenti dengan alasan expired", async () => {
  const { net, screen } = await boot();
  const phone = client(net, "controller", undefined);
  phone.link.start();
  await until(() => phone.t.status === "open", "HP terhubung");
  net.now += LIMITS.idleMs + 1;
  assert.equal(await net.core.sweep(), "expired");
  await until(() => phone.t.status === "closed" && screen.t.status === "closed", "semua berhenti");
  assert.equal(phone.t.reason, "expired");
  assert.equal(screen.t.reason, "expired");
});

test("koneksi mati tanpa tanda (tidak ada pong): terdeteksi dan disambung ulang", async () => {
  const { net, screen } = await boot();
  const phone = client(net, "controller", undefined);
  phone.link.start();
  await until(() => phone.t.status === "open", "HP terhubung");
  net.mute = true; // server tidak membalas apa pun
  await until(() => phone.t.status === "reconnecting", "HP sadar koneksi mati", 3000);
  net.mute = false;
  await until(() => phone.t.status === "open", "HP pulih", 3000);
  assert.equal(phone.link.deviceId, 1);
  phone.link.stop();
  screen.link.stop();
});

test("tanpa jaringan: terus mencoba lalu pulih saat jaringan kembali", async () => {
  const { net, screen } = await boot();
  const phone = client(net, "controller", undefined);
  net.offline = true;
  phone.link.start();
  await sleep(60);
  assert.notEqual(phone.t.status, "open");
  assert.notEqual(phone.t.status, "closed");
  net.offline = false;
  await until(() => phone.t.status === "open", "HP tersambung setelah jaringan pulih", 3000);
  phone.link.stop();
  screen.link.stop();
});

test("kode penutupan terminal tercatat di protokol", () => {
  assert.equal(CLOSE.replaced, 4000);
  assert.equal(CLOSE.notAllowed, 4003);
  assert.equal(CLOSE.full, 4009);
  assert.equal(CLOSE.expired, 4010);
});
````

