# 0 · Mulai: dari nol sampai bisa dicoba

Urutan: **(1)** buat repo GitHub dan dua file akar, **(2)** salin file relay lalu deploy ke Cloudflare, **(3)** salin file web lalu deploy ke Vercel, **(4)** coba.

Cara membuat tiap file di GitHub: **Add file → Create new file**, ketik nama file lengkap dengan folder (garis miring membuat folder otomatis), tempel isinya, lalu **Commit changes**. Kalau tampilan di HP menyulitkan, aktifkan *Desktop site* di browser.

## 1. Buat repo

1. Di github.com: **New repository**, nama bebas (misalnya `main-bareng`), boleh *Private*, lalu **Create repository**.
2. Buat dua file di akar repo dengan isi di bawah (`.gitignore` dan `README.md`).

### `.gitignore`

````
node_modules/
.next/
.wrangler/
.dev.vars
.env
.env.local
.env*.local
*.tsbuildinfo
next-env.d.ts
.DS_Store
````

### `README.md`

````md
# Main Bareng (nama sementara)

Layar besar (TV atau laptop) jadi konsol, HP jadi controller. Tanpa instal, langsung dari browser.
Ini klon gratis konsep AirConsole, dengan game orisinal. Nama dan tampilan masih placeholder.

## Isi repo

| folder | isi | di-deploy ke |
| --- | --- | --- |
| `apps/relay` | relay realtime: Cloudflare Worker + Durable Object (satu objek per kode sesi) | Cloudflare |
| `apps/web` | situs: halaman layar (`/screen`), halaman controller (`/join`) | Vercel |
| `replica/` | dokumen perencanaan (recon, arsitektur, desain), jika Anda menyalinnya | |

## Status

Vertical slice: layar menampilkan kode dan QR, HP bergabung, satu tombol mengetuk dan menampilkan
jeda bolak-balik. Belum ada game, katalog, akun, atau platform developer (lihat `replica/architecture.md`).

## Cara kerja singkat

1. Layar memanggil `POST /v1/sessions` di relay dan mendapat `code` (5 huruf konsonan) dan `host_token`.
2. Layar membuka WebSocket ke `/v1/ws/KODE` dan mengirim `hello` dengan `host_token`.
3. HP membuka `/join`, memasukkan kode (atau memindai QR), lalu `hello` sebagai controller.
4. Pesan antar perangkat lewat relay: `{t:"msg", to: <id|"all">, data: ...}`. Layar selalu `id 0`.

## Perintah (di laptop, bila ada)

```
cd apps/relay && npm install && npm test     # 33 tes: logika relay dan kontrak klien-relay
cd apps/relay && npm run dev                 # relay lokal (wrangler dev)
cd apps/web   && npm install && npm run dev  # situs lokal di http://localhost:3000
```

Di `apps/web`, buat `.env.local` berisi `NEXT_PUBLIC_RELAY_URL=http://localhost:8787` untuk uji lokal.
````

## 2. Relay ke Cloudflare

Salin 5 file dari **1-RELAY.md** dulu. Lalu:

1. Masuk atau daftar di dash.cloudflare.com (gratis). Buka **Workers & Pages** dan buat Worker baru dari repositori Git. Hubungkan akun GitHub Anda dan pilih repo tadi.
2. **Nama Worker: `game-relay`.** Harus sama persis dengan `name` di `wrangler.jsonc`, kalau tidak build gagal.
3. **Root directory: `/apps/relay`.**
4. **Deploy command:** biarkan bawaannya, `npx wrangler deploy`.
5. Simpan dan deploy. Setelah berhasil, catat alamatnya: `https://game-relay.SESUATU.workers.dev`.
6. Cek: buka `ALAMAT/health` di browser. Harus muncul `{"ok":true}`.

Letak menu Cloudflare bisa berubah. Yang penting tiga hal: Worker dibuat dari repo Git, root directory benar, dan namanya cocok.
Paket gratis cukup untuk mencoba (jatah Durable Object 100.000 request per hari).

## 3. Situs ke Vercel

Salin file dari **2-WEB.md**. Lalu:

1. Di vercel.com: **Add New → Project**, pilih repo yang sama.
2. **Root Directory: `apps/web`.** Framework terdeteksi otomatis (Next.js).
3. **Environment Variables:** nama `NEXT_PUBLIC_RELAY_URL`, nilai alamat Cloudflare tadi, **tanpa garis miring di akhir**.
4. **Deploy.** Nilai variabel dibaca saat build, jadi kalau Anda mengisinya sesudah deploy, lakukan **Redeploy**.

## 4. Coba

Butuh dua perangkat: satu sebagai layar (laptop, tablet, atau HP kedua) dan satu HP sebagai controller.

1. Di layar, buka `https://PROYEK-ANDA.vercel.app/screen`. Muncul kode 5 huruf dan QR.
2. Di HP, pindai QR, atau buka `/join` dan ketik kodenya.
3. Ketuk tombol besar. Angka di layar naik, dan di HP tampil `Jeda: N ms`.

Kalau hanya punya satu perangkat, dua tab di browser yang sama cukup untuk uji kasar (tab layar bisa tertahan saat ada di latar belakang).

**Yang saya butuhkan dari Anda setelah mencoba:**

- Berhasil atau tidak. Kalau tidak, salin pesan error persis seperti yang tampil.
- Angka `Jeda` saat HP di Wi-Fi yang sama dengan layar, dan saat memakai data seluler.
- Kunci layar HP selama 30 detik, lalu buka lagi: apakah masih di sesi yang sama dan nomor pemain tetap?

## Kalau gagal

| gejala | kemungkinan penyebab | yang dilakukan |
| --- | --- | --- |
| "Alamat relay belum diatur" | variabel `NEXT_PUBLIC_RELAY_URL` belum diisi, atau diisi setelah deploy | isi lalu **Redeploy** |
| "Relay tidak bisa dihubungi" di `/screen` | alamat salah, Worker belum berhasil deploy, atau situs ditolak relay | buka `ALAMAT/health`; pastikan alamat tanpa `/` di akhir |
| Situs ditolak relay (error 403) | domain situs tidak ada di `ALLOWED_ORIGINS` di `wrangler.jsonc` | alamat `*.vercel.app` sudah termasuk; untuk domain sendiri tambahkan di sana |
| Build di Cloudflare gagal | nama Worker tidak sama dengan `name` di `wrangler.jsonc`, atau root directory salah | samakan nama, isi root `/apps/relay` |
| Build di Vercel gagal | root directory bukan `apps/web`, atau ada file yang kelewat disalin | cek daftar file di 2-WEB.md; kirim log ke saya |
| "Kode tidak ditemukan" terus | salah ketik, atau sesi sudah dihapus (10 menit tanpa layar) | kode hanya berisi konsonan; muat ulang `/screen` untuk kode baru |

Domain sendiri (bukan `*.vercel.app` dan `*.workers.dev`) kita pasang setelah langkah 4 berhasil.
